KellyTools.loadFrontJs(function() {
    KellyDPage.init();
});