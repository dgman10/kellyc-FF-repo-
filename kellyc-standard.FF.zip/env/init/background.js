KellyEDispetcher.init();

// keep empty space to prevent syntax errors if some symbols will added at end